/**
 * 
 */
package com.demo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.demo.bean.CustomerAccounts;
 
/**
 * AbstractDAO.java
 * This DAO class provides CRUD database operations for the table book
 * in the database.
 * @author www.codejava.net
 *
 */
public class AccountTransactionImpl {
    private String jdbcURL;
    private String jdbcUsername;
    private String jdbcPassword;
    private Connection jdbcConnection;
     
    public AccountTransactionImpl(String jdbcURL, String jdbcUsername, String jdbcPassword) {
        this.jdbcURL = jdbcURL;
        this.jdbcUsername = jdbcUsername;
        this.jdbcPassword = jdbcPassword;
    }
     
    protected void connect() throws SQLException {
        if (jdbcConnection == null || jdbcConnection.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            jdbcConnection = DriverManager.getConnection(
                                        jdbcURL, jdbcUsername, jdbcPassword);
        }
    }
     
    protected void disconnect() throws SQLException {
        if (jdbcConnection != null && !jdbcConnection.isClosed()) {
            jdbcConnection.close();
        }
    }
    
    public List<CustomerAccounts> getCustomerAccountsByAccountId(String accountId) throws SQLException{
    	List<CustomerAccounts> listCustomerAccounts = new ArrayList();
        String sql = "SELECT C.CUSTOMER_ID,C.FRIST_NAME,C.LAST_NAME,A.ACCOUNT_ID,A.ACCOUNT_TYPE,A.BALANCE FROM CUSTOMER C,ACCOUNT A WHERE C.CUSTOMER_ID=A.CUSTOMER_ID AND A.ACCOUNT_ID= '"+accountId+"'";
        connect();
        Statement statement = jdbcConnection.createStatement();
        
        ResultSet resultSet = statement.executeQuery(sql);
        
        while (resultSet.next()) {
            String  CUSTOMER_ID = resultSet.getString("CUSTOMER_ID");
            String FRIST_NAME = resultSet.getString("FRIST_NAME");
            String LAST_NAME = resultSet.getString("LAST_NAME");
            String ACCOUNT_ID = resultSet.getString("ACCOUNT_ID");
            String ACCOUNT_TYPE = resultSet.getString("ACCOUNT_TYPE");
            double BALANCE = resultSet.getDouble("BALANCE");
             
            CustomerAccounts customerAccounts = new CustomerAccounts(CUSTOMER_ID, FRIST_NAME, LAST_NAME, ACCOUNT_ID, ACCOUNT_TYPE, BALANCE);
            listCustomerAccounts.add(customerAccounts);
        }
         
        resultSet.close();
        statement.close();
         
        disconnect();
        return listCustomerAccounts;
    }
    
    public List<CustomerAccounts> getCustomerAccountsByCustomerId(String customerId) throws SQLException{
    	List<CustomerAccounts> listCustomerAccounts = new ArrayList();
        String sql = "SELECT C.CUSTOMER_ID,C.FRIST_NAME,C.LAST_NAME,A.ACCOUNT_ID,A.ACCOUNT_TYPE,A.BALANCE FROM CUSTOMER C,ACCOUNT A WHERE C.CUSTOMER_ID=A.CUSTOMER_ID AND C.CUSTOMER_ID= '"+customerId+"'";
        connect();
        Statement statement = jdbcConnection.createStatement();
        
        ResultSet resultSet = statement.executeQuery(sql);
        
        while (resultSet.next()) {
            String  CUSTOMER_ID = resultSet.getString("CUSTOMER_ID");
            String FRIST_NAME = resultSet.getString("FRIST_NAME");
            String LAST_NAME = resultSet.getString("LAST_NAME");
            String ACCOUNT_ID = resultSet.getString("ACCOUNT_ID");
            String ACCOUNT_TYPE = resultSet.getString("ACCOUNT_TYPE");
            double BALANCE = resultSet.getDouble("BALANCE");
             
            CustomerAccounts customerAccounts = new CustomerAccounts(CUSTOMER_ID, FRIST_NAME, LAST_NAME, ACCOUNT_ID, ACCOUNT_TYPE, BALANCE);
            listCustomerAccounts.add(customerAccounts);
        }
         
        resultSet.close();
        statement.close();
         
        disconnect();
        return listCustomerAccounts;
    }
    
    public List<CustomerAccounts> getCustomerAccountsByLastName(String lastName) throws SQLException{
    	List<CustomerAccounts> listCustomerAccounts = new ArrayList();
        String sql = "SELECT C.CUSTOMER_ID,C.FRIST_NAME,C.LAST_NAME,A.ACCOUNT_ID,A.ACCOUNT_TYPE,A.BALANCE FROM CUSTOMER C,ACCOUNT A WHERE C.CUSTOMER_ID=A.CUSTOMER_ID AND UPPER(C.LAST_NAME)  LIKE UPPER('%"+lastName+"%')";
        connect();
        Statement statement = jdbcConnection.createStatement();
        
        ResultSet resultSet = statement.executeQuery(sql);
        
        while (resultSet.next()) {
            String  CUSTOMER_ID = resultSet.getString("CUSTOMER_ID");
            String FRIST_NAME = resultSet.getString("FRIST_NAME");
            String LAST_NAME = resultSet.getString("LAST_NAME");
            String ACCOUNT_ID = resultSet.getString("ACCOUNT_ID");
            String ACCOUNT_TYPE = resultSet.getString("ACCOUNT_TYPE");
            double BALANCE = resultSet.getDouble("BALANCE");
             
            CustomerAccounts customerAccounts = new CustomerAccounts(CUSTOMER_ID, FRIST_NAME, LAST_NAME, ACCOUNT_ID, ACCOUNT_TYPE, BALANCE);
            listCustomerAccounts.add(customerAccounts);
        }
         
        resultSet.close();
        statement.close();
         
        disconnect();
        return listCustomerAccounts;
    }
    
    public boolean updateBalanceByCustomerId(String customerId, String depositAmount) throws SQLException {
    	
    	String sql = "UPDATE ACCOUNT A SET A.BALANCE=A.BALANCE+"+Double.parseDouble(depositAmount)+" WHERE A.CUSTOMER_ID = '"+customerId+"'";
		try {
			connect();
			Statement statement = jdbcConnection.createStatement();
			statement.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		finally {
			disconnect();
		}
    	
    	return true;
    }
public boolean updateWithDrawBalanceByCustomerId(String customerId, String withDrawAmount) throws SQLException {
    	
    	String sql = "UPDATE ACCOUNT A SET A.BALANCE=A.BALANCE-"+Double.parseDouble(withDrawAmount)+" WHERE A.CUSTOMER_ID = '"+customerId+"'";
		try {
			connect();
			Statement statement = jdbcConnection.createStatement();
			statement.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		finally {
			disconnect();
		}
    	
    	return true;
    }
}
