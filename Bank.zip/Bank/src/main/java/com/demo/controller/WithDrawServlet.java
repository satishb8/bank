package com.demo.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.demo.bean.CustomerAccounts;
import com.demo.dao.AccountTransactionImpl;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DepositServlet
 */
public class WithDrawServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AccountTransactionImpl accountTransaction;
	
	 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WithDrawServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public void init() {
        String jdbcURL = getServletContext().getInitParameter("jdbcURL");
		String jdbcUsername = getServletContext().getInitParameter("jdbcUsername");
		String jdbcPassword = getServletContext().getInitParameter("jdbcPassword");

		accountTransaction = new AccountTransactionImpl(jdbcURL, jdbcUsername, jdbcPassword);
    }
      


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String customerId = (String) request.getParameter("customerId");
		String withDrawAmt = (String) request.getParameter("withdrawAmt");
		System.out.println("customerId :: "+customerId);
		System.out.println("withDrawAmt :: "+withDrawAmt);
		boolean status = false;
		CustomerAccounts customerAccount = null;
		try {
			status = accountTransaction.updateWithDrawBalanceByCustomerId(customerId, withDrawAmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			List<CustomerAccounts> customerAccountsList = accountTransaction.getCustomerAccountsByCustomerId(customerId);
			if(customerAccountsList!=null && customerAccountsList.size()>0) {
				customerAccount = customerAccountsList.get(0);
			}
			request.setAttribute("customerAccount", customerAccount);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		request.setAttribute("withdrawstatus", status);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(
		          "/WEB-INF/views/Transaction.jsp");		
		dispatcher.forward(request, response);
	}

}
