package com.demo.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.bean.CustomerAccounts;
import com.demo.dao.AccountTransactionImpl;

/**
 * Servlet implementation class AccountsServlet
 */
public class AccountsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AccountTransactionImpl accountTransaction;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AccountsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {
		String jdbcURL = getServletContext().getInitParameter("jdbcURL");
		String jdbcUsername = getServletContext().getInitParameter("jdbcUsername");
		String jdbcPassword = getServletContext().getInitParameter("jdbcPassword");

		accountTransaction = new AccountTransactionImpl(jdbcURL, jdbcUsername, jdbcPassword);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/Accounts.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String searchBy = (String)request.getParameter("searchBy");
		String searchValue = (String)request.getParameter("searchValue");
		
		System.out.println("searchBy :::::::::: "+searchBy);
		System.out.println("searchValue :::::::::: "+searchValue);
		
		List<CustomerAccounts> customerAccounts = null;
		try {
			
			if(searchBy.equalsIgnoreCase("accountId")) {
				customerAccounts = accountTransaction.getCustomerAccountsByAccountId(searchValue);
				request.setAttribute("customerAccounts", customerAccounts);
				
				RequestDispatcher dispatcher = request.getRequestDispatcher(
				          "/WEB-INF/views/Accounts.jsp");
				dispatcher.forward(request, response);
				
			}else if(searchBy.equalsIgnoreCase("customerId")) {
				customerAccounts = accountTransaction.getCustomerAccountsByCustomerId(searchValue);
			}else if(searchBy.equalsIgnoreCase("lastName")) {
				customerAccounts = accountTransaction.getCustomerAccountsByLastName(searchValue);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		request.setAttribute("customerAccounts", customerAccounts);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/Accounts.jsp");
		dispatcher.forward(request, response);
	}

}
