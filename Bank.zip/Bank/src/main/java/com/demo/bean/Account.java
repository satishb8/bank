package com.demo.bean;

import java.util.Date;

public class Account {
	private String accountId;
	private String customerId;
	private String accountType;
	private String status;
	private Double balance;
	private Date lastTransaction;
	
	public Account() {
		super();
	}
	
	public Account(String accountId, String customerId, String accountType, String status, Double balance,
			Date lastTransaction) {
		super();
		this.accountId = accountId;
		this.customerId = customerId;
		this.accountType = accountType;
		this.status = status;
		this.balance = balance;
		this.lastTransaction = lastTransaction;
	}



	public String getAccountId() {
		return accountId;
	}


	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}


	public String getCustomerId() {
		return customerId;
	}


	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}


	public String getAccountType() {
		return accountType;
	}


	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Double getBalance() {
		return balance;
	}


	public void setBalance(Double balance) {
		this.balance = balance;
	}


	public Date getLastTransaction() {
		return lastTransaction;
	}


	public void setLastTransaction(Date lastTransaction) {
		this.lastTransaction = lastTransaction;
	}


}
